const vehicle = {
    vehicleid: 4876,
    brand: 'Kia',
    model: '2019',
    varient: 'top model',
    specification: {
        firstGear: function () {
            console.log('vehicle in first gear');
        },
        secondGear: function () {
            console.log('vehicle in second gear');
        },
        maxSpeed: 90,
        changeGear: function () {
            return (this.firstGear(), this.secondGear());
        },},}
console.log(`The vehicleid is:${vehicle.vehicleid}`);
console.log(`The vehicle brand is:${vehicle.brand}`);
console.log(`The vehicle model is:${vehicle.model}`);
console.log(`The vehicle varient is:${vehicle.varient}`);
vehicle.specification.changeGear();
console.log(vehicle.specification.maxSpeed);