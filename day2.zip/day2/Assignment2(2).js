sum = (p,q,r,s) => {
    return(p+q+r+s)
  }
    z= sum(17,33,27,84)
    console.log(z);