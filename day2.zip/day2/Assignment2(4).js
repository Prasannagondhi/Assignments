function login(username='CT',password='CT'){
    console.log('username is:'+username);
    console.log('password is:'+password); 
};
login('puppy','0000000');
login('puppy');