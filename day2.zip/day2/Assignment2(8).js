function sum(...x) {
    res = 0;
    for (i = 0; i < x.length; i++) {
        res += x[i];
    }
    console.log(`The Sum = ${res}`);
}
sum(11,44,66,87,33);
sum();