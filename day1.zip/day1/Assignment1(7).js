var nums = [1, 5, 6, 10, 13];
        var factorials = new Array();
        var result;

        for (let i = 0; i < nums.length; i++) {
            let result = getFactorial(nums[i]);
            console.log(result);
            factorials.push(result);
        }
        function getFactorial(num) {
            let fact = 1;
            for (i = 1; i <= num; i++) {
                fact *= i;
            }
            return fact;
        }